package com.example;

import java.util.ArrayList;

import com.example.models.Chamado;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML TextField txtUsuario;
    @FXML TextField txtCodigo_Equipamento;
    @FXML RadioButton rbComputador;
    @FXML RadioButton rbImpressora;
    @FXML RadioButton rbRede;
    @FXML CheckBox cbPrimeiroContato;
    @FXML CheckBox cbAtendido;
    @FXML CheckBox cbEncerrado;
    @FXML ListView<Chamado> lista;
    @FXML Button btnConfirmar;
    @FXML Button btnRemover;
    @FXML Button btnAlterar;

    ArrayList<Chamado> chamados = new ArrayList<>();

    public void initialize() {
        selecionaUmApenas();

        
    lista.setOnMouseClicked(event -> {
        if (event.getClickCount() == 2) { 
            pegaCampos();
        }
    });
    }

    private void selecionaUmApenas() {
        rbComputador.setOnAction(event -> {
            rbImpressora.setSelected(false);
            rbRede.setSelected(false);
        });

        rbImpressora.setOnAction(event -> {
            rbComputador.setSelected(false);
            rbRede.setSelected(false);
        });

        rbRede.setOnAction(event -> {
            rbComputador.setSelected(false);
            rbImpressora.setSelected(false);
        });

    }

    public void adicionar() {

        if (validarEntradas()) {
            ArrayList<String> atividades = new ArrayList<>();
        
            CheckBox[] checkboxes = {cbPrimeiroContato, cbAtendido, cbEncerrado};
            
            for (CheckBox checkbox : checkboxes) {
                if (checkbox.isSelected()) {
                    atividades.add(checkbox.getText());
                }
            }
    
            RadioButton[] radioButtons = {rbComputador, rbImpressora, rbRede};
            String radiobt = "";
            for (RadioButton radioButton : radioButtons){
                if (radioButton.isSelected()){
                    radiobt = radioButton.getText();
                    break;
                }
            }
        
            var chamado = new Chamado(txtUsuario.getText(), Integer.parseInt(txtCodigo_Equipamento.getText()), radiobt, atividades);
            chamados.add(chamado);
            mostrarNaLista();
            limparCampos();
        }   
    }
    

    public void mostrarNaLista() {
        lista.getItems().clear();
        for (Chamado chamado : chamados) {
            lista.getItems().add(chamado);
        }

    }

    public void apagar(){
        var item = lista.getSelectionModel().getSelectedItem();
        chamados.remove(item);
        mostrarNaLista();

    }

    public void alterar() {
        if (validarEntradas()) {
            ArrayList<String> atividades = new ArrayList<>();
        
            CheckBox[] checkboxes = {cbPrimeiroContato, cbAtendido, cbEncerrado};
        
            for (CheckBox checkbox : checkboxes) {
                if (checkbox.isSelected()) {
                    atividades.add(checkbox.getText());
                }
            }
        
            RadioButton[] radioButtons = {rbComputador, rbImpressora, rbRede};
            String radiobt = "";
            for (RadioButton radioButton : radioButtons) {
                if (radioButton.isSelected()) {
                    radiobt = radioButton.getText();
                    break;
                }
            }
        
            Chamado chamadoSelecionado = lista.getSelectionModel().getSelectedItem();
            if (chamadoSelecionado != null) {
                chamadoSelecionado.setUsuario(txtUsuario.getText());
                chamadoSelecionado.setCodEquipamento(Integer.parseInt(txtCodigo_Equipamento.getText()));
                chamadoSelecionado.setCategoria(radiobt);
                chamadoSelecionado.setAtividades(atividades);
                mostrarNaLista();
                limparCampos();
            }
        }
    }

    public void pegaCampos(){
        var item = lista.getSelectionModel().getSelectedItem();

        txtUsuario.setText(item.getUsuario());
        txtCodigo_Equipamento.setText(String.valueOf(item.getCodEquipamento()));
    
        CheckBox[] checkboxes = {cbPrimeiroContato, cbAtendido, cbEncerrado};
    
        for (CheckBox checkbox : checkboxes) {
            if (item.getAtividades().contains(checkbox.getText())) {
                checkbox.setSelected(true);
            }
        }
    
        RadioButton[] radioButtons = {rbComputador, rbImpressora, rbRede};
        for (RadioButton radioButton : radioButtons) {
            if (item.getCategoria().contains(radioButton.getText())) {
                radioButton.setSelected(true);
                break;
            }
        }
    }

   private void limparCampos() {
    txtUsuario.clear();
    txtCodigo_Equipamento.clear();
    rbComputador.setSelected(false);
    rbImpressora.setSelected(false);
    rbRede.setSelected(false);
    cbPrimeiroContato.setSelected(false);
    cbAtendido.setSelected(false);
    cbEncerrado.setSelected(false);
    txtUsuario.requestFocus();
    }
    
    private boolean validarEntradas() {
        if (txtUsuario.getText().isEmpty() || txtCodigo_Equipamento.getText().isEmpty()) {
            mostrarAlerta("Erro", "Campos obrigatórios não preenchidos.");
            txtUsuario.requestFocus();
            return false;
        }

        try {
            Integer.parseInt(txtCodigo_Equipamento.getText());
        } catch (NumberFormatException e) {
            mostrarAlerta("Erro", "Código de equipamento inválido. Insira um número válido.");
            txtCodigo_Equipamento.clear();
            txtCodigo_Equipamento.requestFocus();
            return false;
        }

        if (!rbComputador.isSelected() && !rbImpressora.isSelected() && !rbRede.isSelected()) {
            mostrarAlerta("Erro", "Selecione uma categoria.");
            return false;
        }

        return true;
    }

     private void mostrarAlerta(String título, String mensagem) {
        Alert alerta = new Alert(AlertType.ERROR);
        alerta.setTitle(título);
        alerta.setHeaderText(null);
        alerta.setContentText(mensagem);
        alerta.showAndWait();
    }
}
