package com.example.models;

import java.util.ArrayList;

public class Chamado {
    private String usuario;
    private int codEquipamento;
    private String categoria;
    private ArrayList<String> atividades;

    public Chamado(String usuario, int codEquipamento, String categoria, ArrayList<String> atividades) {
        this.usuario = usuario;
        this.codEquipamento = codEquipamento;
        this.categoria = categoria;
        this.atividades = atividades;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getCodEquipamento() {
        return codEquipamento;
    }

    public void setCodEquipamento(int codEquipamento) {
        this.codEquipamento = codEquipamento;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public ArrayList<String> getAtividades() {
        return atividades;
    }

    public void setAtividades(ArrayList<String> atividades) {
        this.atividades = atividades;
    }

    @Override
    public String toString() {
        StringBuilder atividadesStr = new StringBuilder();
        for (int i = 0; i < atividades.size(); i++) {
            atividadesStr.append(atividades.get(i));
            if (i < atividades.size() - 1) {
                atividadesStr.append(", ");
            }
        }
        
        return "Usuario: " + usuario + " | Codigo do Equipamento: " + codEquipamento + " | Categoria: " + categoria + " | Atividades: " + atividadesStr.toString();
    }

}
